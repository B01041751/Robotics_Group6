#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
import math

class Explorer:

    def __init__(self):
        rospy.init_node('explorer')

        self.pub = rospy.Publisher('cmd_vel', Twist, queue_size=10)
        rospy.Subscriber('scan', LaserScan, self.scan_callback)

    def scan_callback(self, msg):
        ranges = msg.ranges

        # Clean data
        ranges = [r if not math.isinf(r) else 10 for r in ranges]

        n = len(ranges)

        # Better region selection
        front = min(ranges[n//2 - 30 : n//2 + 30])
        left  = min(ranges[n//2 + 30 : n//2 + 90])
        right = min(ranges[n//2 - 90 : n//2 - 30])

        self.move(front, left, right)

    def move(self, front, left, right):
        twist = Twist()

        # 🚨 ESCAPE condition
        if front < 0.4 and left < 0.4 and right < 0.4:
            rospy.logwarn("Stuck → spinning")
            twist.angular.z = 1.5

        # 🚨 Obstacle ahead
        elif front < 0.6:
            rospy.loginfo("Obstacle ahead → turning")

            twist.linear.x = 0.05  # small forward motion

            if left > right:
                twist.angular.z = 1.0
            else:
                twist.angular.z = -1.0

        # 🚧 Wall on left
        elif left < 0.4:
            twist.linear.x = 0.2
            twist.angular.z = -0.5

        # 🚧 Wall on right
        elif right < 0.4:
            twist.linear.x = 0.2
            twist.angular.z = 0.5

        # ✅ Free space
        else:
            twist.linear.x = 0.3

        self.pub.publish(twist)


if __name__ == '__main__':
    try:
        Explorer()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
