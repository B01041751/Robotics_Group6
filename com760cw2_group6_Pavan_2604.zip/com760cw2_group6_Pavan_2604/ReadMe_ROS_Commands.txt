roslaunch com760cw2_group6 group_6_launch.launch
rosclean purge
rostopic list
rosrun com760cw2_group6 hazard_oscillator.py
rosrun com760cw2_group6 move_robot2_circle.py
rosrun com760cw2_group6 Group6Bot_1_camera_view.py __ns:=Group6Bot_1
rosrun com760cw2_group6 Group6Bot_1_explore.py __ns:=Group6Bot_1
rosrun com760cw2_group6 bug_service_server.py __ns:=Group6Bot_1
rosrun com760cw2_group6 bug_service_client.py __ns:=Group6Bot_1
rosrun com760cw2_group6 q_learning_rewards