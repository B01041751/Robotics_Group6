#!/usr/bin/env python3
# rospy is the main ROS Python library used for creating nodes, topics, etc
# Image message type is used to receive camera images from ROS
#  CvBridge converts ROS Image messages into OpenCV images
# OpenCV library used for image processing and display
import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2

class CameraViewer:

    def __init__(self):
    	# Initialize the ROS node with the name 'camera_viewer'
        rospy.init_node('camera_viewer')

        self.bridge = CvBridge()

        rospy.Subscriber('camera/image_raw', Image, self.callback)
	# Callback function that runs whenever a new image is received
    def callback(self, msg):
        try:
            # Convert ROS image to OpenCV image
            cv_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

            # Show image
            cv2.imshow("Robot Camera", cv_image)
            cv2.waitKey(1)

        except Exception as e:
            rospy.logerr("Error: %s", e)
# Main entry point of the script
if __name__ == '__main__':
    try:
    	# Create an instance of the CameraViewer class
        CameraViewer()
        # Keep the node running and listening for messages
        rospy.spin()
    except rospy.ROSInterruptException:
    	# Handle the case where ROS shuts down (Ctrl+C)
        pass
