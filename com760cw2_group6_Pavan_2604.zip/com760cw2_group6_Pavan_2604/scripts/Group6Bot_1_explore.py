#!/usr/bin/env python3
# rospy is the ROS Python library used to create nodes and communicate with ROS
# LaserScan message is used to receive LiDAR scan data
# Twist message is used to send velocity commands to the robot
# Math library is used here to check infinite distance values

import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
import math

class Explorer:

    def __init__(self):
        rospy.init_node('explorer')

        self.pub = rospy.Publisher('cmd_vel', Twist, queue_size=10)
        rospy.Subscriber('scan', LaserScan, self.scan_callback)

        # Recovery state
        self.recovering = False
        self.recover_step = 0
        self.recover_start_time = rospy.Time.now()

    def scan_callback(self, msg):
        ranges = [r if not math.isinf(r) else 10 for r in msg.ranges]
	# Total number of laser readings
        n = len(ranges)
	# Take minimum distance from front area
        front = min(ranges[n//2 - 30 : n//2 + 30])
        # Take minimum distance from left side
        left  = min(ranges[n//2 + 30 : n//2 + 90])
        # Take minimum distance from right side
        right = min(ranges[n//2 - 90 : n//2 - 30])

        self.move(front, left, right)

    def move(self, front, left, right):
        twist = Twist()
        now = rospy.Time.now()

        # =========================
        # RECOVERY MODE
        # =========================
        if self.recovering:

            elapsed = (now - self.recover_start_time).to_sec()

            # Step 1: Reverse
            if self.recover_step == 0:
                twist.linear.x = -0.2
                twist.angular.z = 0.0

                if elapsed > 1.0:
                    self.recover_step = 1
                    self.recover_start_time = now

            # Step 2: Move forward
            elif self.recover_step == 1:
                twist.linear.x = 0.3
                twist.angular.z = 0.0

                if elapsed > 1.0:
                    self.recovering = False  # done recovery

            self.pub.publish(twist)
            return

        # =========================
        # DETECT STUCK
        # =========================
        if front < 0.4 and left < 0.4 and right < 0.4:
            rospy.logwarn("Stuck → reversing then moving forward")

            self.recovering = True
            self.recover_step = 0
            self.recover_start_time = now
            return

        # =========================
        # Obstacle ahead
        # =========================
        elif front < 0.6:
            rospy.loginfo("Obstacle ahead → turn")

            twist.linear.x = 0.0
            twist.angular.z = -1.0  # turn right

        # Wall on left
        elif left < 0.4:
            twist.linear.x = 0.2
            twist.angular.z = -0.5

        # Wall on right
        elif right < 0.4:
            twist.linear.x = 0.2
            twist.angular.z = 0.5

        # Free space
        else:
            twist.linear.x = 0.3

        self.pub.publish(twist)


if __name__ == '__main__':
    try:
    	# Create Explorer object
        Explorer()
        # Keep node running
        rospy.spin()
    except rospy.ROSInterruptException:
    	# Handle shutdown safely
        pass
