#!/usr/bin/env python3
# rospy is the main ROS Python library used to create nodes, services, and topics
# LaserScan message is used to receive distance data from the LiDAR sensor
# Twist message is used to send linear and angular velocity commands to the robot
# Odometry message provides the robot's position and orientation information
# Math functions are used for distance calculation, angle computation, and navigation logic
# Custom service used to start or control the Bug2 navigation behaviour
import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from math import sqrt, atan2, cos, sin, pi
from com760cw2_group6.srv import StartBug2, StartBug2Response


class Bug2:

    def __init__(self):
        rospy.init_node('bug2_controller')

        # publishers and subscribers
        robot_ns = rospy.get_namespace()

        self.cmd_pub = rospy.Publisher(robot_ns + 'cmd_vel', Twist, queue_size=10)
        rospy.Subscriber(robot_ns + 'scan', LaserScan, self.scan_callback)
        rospy.Subscriber(robot_ns + 'odom', Odometry, self.odom_callback)

        # service to start Bug2
        self.service = rospy.Service('/Group6Bot_1/start_bug2', StartBug2, self.start_callback)
        rospy.loginfo(f"service to start Bug2")

        # robot state
        self.x = 0
        self.y = 0
        self.yaw = 0

        self.goal_x = 0
        self.goal_y = 0

        self.active = False
        self.mode = "GO_TO_GOAL"

        # speeds
        self.forward_speed = 0.3
        self.wall_speed = 0.15

        # M-line parameters
        self.start_x = 0
        self.start_y = 0

        self.front = 10
        self.left = 10
        self.right = 10

    # =========================
    # SERVICE: START BUG2
    # =========================
    def start_callback(self, req):

        self.goal_x = req.goal_x
        self.goal_y = req.goal_y

        self.start_x = self.x
        self.start_y = self.y

        self.active = True
        self.mode = "GO_TO_GOAL"

        rospy.loginfo(f"Bug2 started → Goal: ({self.goal_x}, {self.goal_y})")

        return StartBug2Response(True)

    # =========================
    # ODOMETRY CALLBACK
    # =========================
    def odom_callback(self, msg):

        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y

        # yaw extraction
        orientation = msg.pose.pose.orientation
        siny = 2 * (orientation.w * orientation.z + orientation.x * orientation.y)
        cosy = 1 - 2 * (orientation.y**2 + orientation.z**2)
        self.yaw = atan2(siny, cosy)

    # =========================
    # LASER CALLBACK
    # =========================
    def scan_callback(self, msg):

        ranges = [r if not (r == float('inf')) else 10 for r in msg.ranges]
        n = len(ranges)

        self.front = min(ranges[n//2 - 20:n//2 + 20])
        self.left  = min(ranges[n//2 + 20:n//2 + 80])
        self.right = min(ranges[n//2 - 80:n//2 - 20])

        self.move()

    # =========================
    # MAIN CONTROL
    # =========================
    def move(self):

        if not self.active:
            return

        twist = Twist()

        # distance to goal
        dist_goal = sqrt((self.goal_x - self.x)**2 + (self.goal_y - self.y)**2)

        # goal reached
        if dist_goal < 0.2:
            rospy.loginfo("Goal reached!")
            self.active = False
            return

        # =========================
        # MODE: GO TO GOAL
        # =========================
        if self.mode == "GO_TO_GOAL":

            angle_to_goal = atan2(self.goal_y - self.y, self.goal_x - self.x)
            error = angle_to_goal - self.yaw

            # normalize angle
            error = atan2(sin(error), cos(error))

            twist.linear.x = self.forward_speed
            twist.angular.z = 1.5 * error

            # obstacle detected → switch to wall following
            if self.front < 0.5:
                rospy.logwarn("Obstacle hit → switching to wall follow")
                self.mode = "FOLLOW_WALL"

        # =========================
        # MODE: FOLLOW WALL
        # =========================
        elif self.mode == "FOLLOW_WALL":

            twist.linear.x = self.wall_speed

            # keep wall on right side
            if self.right < 0.4:
                twist.angular.z = 0.3
            else:
                twist.angular.z = -0.3

            # check if back on M-line
            if self.on_m_line() and self.closer_to_goal():
                rospy.loginfo("Back to M-line → going to goal")
                self.mode = "GO_TO_GOAL"

        self.cmd_pub.publish(twist)

    # =========================
    # CHECK M-LINE
    # =========================
    def on_m_line(self):

        # line equation Ax + By + C = 0
        A = self.goal_y - self.start_y
        B = self.start_x - self.goal_x
        C = self.goal_x * self.start_y - self.start_x * self.goal_y

        distance = abs(A*self.x + B*self.y + C) / sqrt(A**2 + B**2)

        return distance < 0.1

    # =========================
    # CHECK IF CLOSER TO GOAL
    # =========================
    def closer_to_goal(self):

        current_dist = sqrt((self.goal_x - self.x)**2 + (self.goal_y - self.y)**2)
        start_dist = sqrt((self.goal_x - self.start_x)**2 + (self.goal_y - self.start_y)**2)

        return current_dist < start_dist


if __name__ == '__main__':
    try:
        Bug2()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
